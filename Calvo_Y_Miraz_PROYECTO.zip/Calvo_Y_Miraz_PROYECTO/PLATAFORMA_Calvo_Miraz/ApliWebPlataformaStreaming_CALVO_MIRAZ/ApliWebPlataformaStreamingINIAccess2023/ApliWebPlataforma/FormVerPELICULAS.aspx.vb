﻿Public Class FormVerPELICULAS
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LabelFecha.Text = " " & DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss")
        End If
    End Sub


    Protected Sub mostrar_Click(sender As Object, e As EventArgs) Handles mostrar.Click
        Dim varNombre As String 'Se declara una variable de tipo string llamada varNombre
        varNombre = Me.Nombre.Text 'Se asigna a esa variable el valor de la caja de texto
        Me.Mensaje.Text = ”Hola “ & varNombre & “ !” 'Se concatena con & y se pone en el Label
    End Sub

    Protected Sub AccessDataSource1_Selecting(sender As Object, e As SqlDataSourceSelectingEventArgs) Handles AccessDataSource1.Selecting

    End Sub

    Protected Sub AccessDataSource3_Selecting(sender As Object, e As SqlDataSourceSelectingEventArgs) Handles AccessDataSource3.Selecting

    End Sub
End Class