Imports System.Data.OleDb 'Para las conexiones tipo OleDb -- ACCESS
Public Class FormularioFuncionesUSUARIO
    Inherits System.Web.UI.Page
    'Asigna a Usuario el LoginName actual pasado a min�sculas (para las comparaciones)
    Dim usuario As String = StrConv(System.Web.HttpContext.Current.User.Identity.Name, VbStrConv.Lowercase)
    'Indicamos la cadena de conexion (tipo OLEDB)
    Dim cadenaConexion As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\TEMP\Plataforma_CALVO_MIRAZ.mdb"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Comprobamos que se haya iniciado sesi�n
        If usuario = "" Then
            MsgBox("Debes Iniciar Sesi�n como usuario registrado para poder operar aqu�")
            Response.Redirect("default.aspx")
        End If
        If Page.IsPostBack = False Then 'Solamente se hace cuando vaya a esta p�gina
            'DECLARAR LAS VARIABLES NECESARIAS para las instrucciones de BD
            Dim conexion As OleDb.OleDbConnection
            Dim strSQL As String
            Dim dbComm As OleDbCommand
            'PASO 1. CREAR UNA CONEXION Y ABRIRLA
            conexion = New OleDb.OleDbConnection(cadenaConexion)
            conexion.Open()
            '*******************************************************************************************
            ' SE RECUPERA EL ESTADO DEL USUARIO QUE HA INICIADO LA SESI�N
            '*******************************************************************************************
            'PASOS 2 Y 3. PREPARAR LA INSTRUCCION SQL Y EJECUTARLA
            strSQL = "SELECT estado FROM USUARIOREG WHERE usuarioLogin=?"
            dbComm = New OleDbCommand(strSQL, conexion)
            dbComm.Parameters.Add(New OleDbParameter("usuario", OleDbType.VarChar)).Value = usuario
            Dim estado As String  'Para guardar el estado del usuario en la aplicaci�n
            estado = dbComm.ExecuteScalar()    ' Ejecuta una SELECT en la que solo se obtiene un dato

            '*******************************************************************************************
            ' SI ES UN USUARIO REGISTRADO ACTIVO (su estado es A), SE MUESTRAN SUS DATOS PERSONALES
            '*******************************************************************************************
            If estado <> "A" Then
                'Si su estado no es activo visualizar un mensaje
                MsgBox("Has sido dado de baja por el administrador de la plataforma. No puedes operar.")
                Response.Redirect("default.aspx")
            Else
                'Recuperar los dem�s datos del usuario desde la BD y mostrarlos -- EJEMPLO DE SELECT
                'PASO 2. Preparar la instrucci�n SQL a ejecutar
                strSQL = "SELECT nombre_apellido,direccion,credito FROM USUARIOREG WHERE usuarioLogin='" & usuario & "'"
                dbComm = New OleDbCommand(strSQL, conexion)
                'PASO 3. Ejecutarla
                Dim datosUsuarioReader As OleDbDataReader
                datosUsuarioReader = dbComm.ExecuteReader()  'Ejecuta una SELECT que obtiene varios datos
                'Tratar el resultado, es decir, los datos obtenidos por la select
                While datosUsuarioReader.Read() 'Si hay varias filas las va leyendo una por una
                    'Se asignan los datos recuperados a los distintos TextBox de la p�gina Web
                    Me.Nombre.Text = datosUsuarioReader(0) 'Primer dato de la fila
                    Me.Direccion.Text = datosUsuarioReader(1) 'Segundo dato de la fila
                End While
            End If
            'PASO 4. CERRAR LA CONEXI�N Y LIBERAR MEMORIA
            conexion.Close()
            conexion.Dispose()
        End If
    End Sub


    Protected Sub VolverPrincipal_Click(ByVal sender As Object, ByVal e As EventArgs) Handles VolverPrincipal.Click
        Response.Redirect("default.aspx")
    End Sub

    Protected Sub Aumentar_Click(sender As Object, e As EventArgs)

    End Sub

    Protected Sub Aumentar_Click1(sender As Object, e As EventArgs)

    End Sub

    Protected Sub Aumentar_Click2(sender As Object, e As EventArgs)

    End Sub

    Protected Sub Aumentar_Click3(sender As Object, e As EventArgs) Handles Aumentar.Click
        'PASO 0. DECLARAR LAS VARIABLES NECESARIAS para las instrucciones de BD
        Dim conexion As OleDb.OleDbConnection
        Dim instruccionSQL As String
        Dim dbComm As OleDbCommand
        'PASO 1. CREAR UNA CONEXION CON LA BASE DE DATOS Y ABRIRLA
        conexion = New OleDb.OleDbConnection(cadenaConexion)
        conexion.Open()
        'PASO 2. PREPARAR LA INSTRUCCION SQL A EJECUTAR
        'Ponemos la instrucci�n SQL en un string, con un ? en cada sitio en el que vaya un par�metro
        instruccionSQL = "UPDATE USUARIOREG SET credito=credito + ? WHERE usuarioLogin=?"
        'La convertimos en un comando para poder a�adirle los valores de los par�metros
        dbComm = New OleDbCommand(instruccionSQL, conexion)
        'A�adimos los par�metros y especificamos sus valores
        'en el mismo orden en que aparecen en la instrucci�n SQL
        'Valor correspondiente a la primera ? de instruccionSQL
        dbComm.Parameters.Add("param1", OleDbType.Double)
        dbComm.Parameters("param1").Value = CDbl(cantidadEuros.Text)
        'Valor correspondiente a la segunda ? de instruccionSQL
        dbComm.Parameters.Add("param2", OleDbType.VarChar)
        dbComm.Parameters("param2").Value = usuario
        'PASO 3. EJECUTAR LA INSTRUCCION SQL (hay 3 casos distintos, se elige el adecuado)
        dbComm.ExecuteNonQuery() 'Ejecuta cualquier instrucci�n que no sea SELECT
        'Sacamos un mensaje por pantalla (opcional)
        MsgBox("Se ha aumentado el cr�dito del usuario")
        'PASO 4. CERRAR LA CONEXI�N CON LA BASE DE DATOS Y LIBERAR MEMORIA
        conexion.Close()
        conexion.Dispose()
    End Sub

    Protected Sub Modificar_Click(sender As Object, e As EventArgs) Handles Modificar.Click
        'PASO 0. DECLARAR LAS VARIABLES NECESARIAS para las instrucciones de BD
        Dim conexion As OleDb.OleDbConnection
        Dim instruccionSQL As String
        Dim dbComm As OleDbCommand
        'PASO 1. CREAR UNA CONEXION CON LA BASE DE DATOS Y ABRIRLA
        conexion = New OleDb.OleDbConnection(cadenaConexion)
        conexion.Open()
        'PASO 2. PREPARAR LA INSTRUCCION SQL A EJECUTAR
        'Ponemos la instrucci�n SQL en un string, con un ? en cada sitio en el que vaya un par�metro
        instruccionSQL = "UPDATE USUARIOREG SET nombre_apellido=?, direccion=? WHERE usuarioLogin=?"
        'La convertimos en un comando para poder a�adirle los valores de los par�metros
        dbComm = New OleDbCommand(instruccionSQL, conexion)
        'A�adimos los par�metros y especificamos sus valores
        'en el mismo orden en que aparecen en la instrucci�n SQL
        'Valor correspondiente a la primera ? de instruccionSQL
        dbComm.Parameters.Add("param1", OleDbType.VarChar)
        dbComm.Parameters("param1").Value = Nombre.Text
        'Valor correspondiente a la segunda ? de instruccionSQL
        dbComm.Parameters.Add("param2", OleDbType.VarChar)
        dbComm.Parameters("param2").Value = Direccion.Text
        'Valor correspondiente a la tercera ? de instruccionSQL
        dbComm.Parameters.Add("param3", OleDbType.VarChar)
        dbComm.Parameters("param3").Value = usuario
        'PASO 3. EJECUTAR LA INSTRUCCION SQL (hay 3 casos distintos, se elige el adecuado)
        dbComm.ExecuteNonQuery() 'Ejecuta cualquier instrucci�n que no sea SELECT
        'Sacamos un mensaje por pantalla (opcional)
        MsgBox("Se han cambiado los datos")
        'PASO 4. CERRAR LA CONEXI�N CON LA BASE DE DATOS Y LIBERAR MEMORIA
        conexion.Close()
        conexion.Dispose()
    End Sub

    Protected Sub Alquilar_Click(sender As Object, e As EventArgs) Handles Alquilar.Click
        ' Paso 1: crear y abrir la conexi�n
        Dim conexion As OleDbConnection
        conexion = New OleDb.OleDbConnection(cadenaConexion)
        conexion.Open()

        Dim transaccion As OleDbTransaction
        Dim strSQL As String
        Dim dbComm As OleDbCommand

        transaccion = conexion.BeginTransaction()

        Try
            strSQL = "SELECT precio FROM PELICULA WHERE titulo = ?"
            dbComm = New OleDbCommand(strSQL, conexion, transaccion)
            dbComm.Parameters.Add("param1", OleDbType.VarChar)
            dbComm.Parameters("param1").Value = PelisA.SelectedValue
            Dim precio As Integer = dbComm.ExecuteScalar()

            If precio <> 0 Then
                MsgBox("Precio distinto de 0")
                strSQL = "SELECT credito FROM USUARIOREG WHERE usuarioLogin = ?"
                dbComm = New OleDbCommand(strSQL, conexion, transaccion)
                dbComm.Parameters.Add("param1", OleDbType.VarChar)
                dbComm.Parameters("param1").Value = usuario
                Dim credito As Double = dbComm.ExecuteScalar()

                If precio > credito Then
                    MsgBox("NO TE DA LA PASTA")
                Else
                    MsgBox("Tienes 2 dias para verla jarto, si no te cobramos un recargo")

                    ' Actualizar el cr�dito del usuario
                    strSQL = "UPDATE USUARIOREG SET credito=credito-? WHERE usuarioLogin = ?"
                    dbComm = New OleDbCommand(strSQL, conexion, transaccion)
                    dbComm.Parameters.Add("param1", OleDbType.Double)
                    dbComm.Parameters("param1").Value = CDbl(precio)

                    dbComm.Parameters.Add("param2", OleDbType.VarChar)
                    dbComm.Parameters("param2").Value = usuario
                    dbComm.ExecuteNonQuery()
                    MsgBox("Actualizado el credito")

                    ' Obtener el c�digo de la pel�cula
                    strSQL = "SELECT codigo FROM PELICULA WHERE titulo = ?"
                    dbComm = New OleDbCommand(strSQL, conexion, transaccion)
                    dbComm.Parameters.Add("param1", OleDbType.VarChar)
                    dbComm.Parameters("param1").Value = PelisA.SelectedValue
                    Dim codigoP As Integer = dbComm.ExecuteScalar()
                    MsgBox("Obtenido el codigo de la peli")

                    ' Insertar un nuevo registro en la tabla ALQUILER
                    strSQL = "INSERT INTO ALQUILER(usuarioLogin, codigo, FechaFin, FechaInicio,devuelta) VALUES(?,?,?,NOW(),'N')"
                    dbComm = New OleDbCommand(strSQL, conexion, transaccion)

                    dbComm.Parameters.Add("param1", OleDbType.VarChar)
                    dbComm.Parameters("param1").Value = usuario

                    dbComm.Parameters.Add("param2", OleDbType.Integer)
                    dbComm.Parameters("param2").Value = codigoP

                    dbComm.Parameters.Add("param3", OleDbType.Date)
                    dbComm.Parameters("param3").Value = DateTime.Now.AddDays(2).Date


                    dbComm.ExecuteNonQuery()
                    MsgBox("Insertado un nuevo alquiler")

                    ' Actualizar el estado de la pel�cula
                    strSQL = "UPDATE PELICULA SET estado='alquilada' WHERE titulo = ?"
                    dbComm = New OleDbCommand(strSQL, conexion, transaccion)

                    dbComm.Parameters.Add("param1", OleDbType.VarChar)
                    dbComm.Parameters("param1").Value = PelisA.SelectedValue

                    dbComm.ExecuteNonQuery()
                    MsgBox("Cambiado el estado de la peli")
                End If
            Else
                MsgBox("ES gratis")

                ' Obtener el c�digo de la pel�cula
                strSQL = "SELECT codigo FROM PELICULA WHERE titulo = ?"
                dbComm = New OleDbCommand(strSQL, conexion, transaccion)
                dbComm.Parameters.Add("param1", OleDbType.VarChar)
                dbComm.Parameters("param1").Value = PelisA.SelectedValue
                MsgBox("Obtenido el codigo de la peli")


                Dim codigoP As Integer = dbComm.ExecuteScalar()

                ' Insertar un nuevo registro en la tabla ALQUILER
                strSQL = "INSERT INTO ALQUILER(usuarioLogin, codigo,FechaFin, FechaInicio,devuelta) VALUES(?,?,#12/30/9999#,NOW(),'N')"
                dbComm = New OleDbCommand(strSQL, conexion, transaccion)

                dbComm.Parameters.Add("param1", OleDbType.VarChar)
                dbComm.Parameters("param1").Value = usuario

                dbComm.Parameters.Add("param2", OleDbType.Integer)
                dbComm.Parameters("param2").Value = codigoP



                dbComm.ExecuteNonQuery()
                MsgBox("Insertado un nuevo alquiler")

                ' Actualizar el estado de la pel�cula
                strSQL = "UPDATE PELICULA SET estado='alquilada' WHERE titulo = ?"
                dbComm = New OleDbCommand(strSQL, conexion, transaccion)
                dbComm.Parameters.Add("param1", OleDbType.VarChar)
                dbComm.Parameters("param1").Value = PelisA.SelectedValue
                dbComm.ExecuteNonQuery()
                MsgBox("Actualizado el estado de la peli")
            End If

            transaccion.Commit()
        Catch ex As Exception
            MsgBox(ex.Message)
            transaccion.Rollback()
        Finally
            conexion.Close()
            conexion.Dispose()
        End Try
    End Sub

    Protected Sub Devolver_Click(sender As Object, e As EventArgs) Handles Devolver.Click

        ' Paso 1: crear y abrir la conexi�n
        Dim conexion As OleDbConnection
        conexion = New OleDb.OleDbConnection(cadenaConexion)
        conexion.Open()

        Dim transaccion As OleDbTransaction
        Dim strSQL As String
        Dim dbComm As OleDbCommand

        transaccion = conexion.BeginTransaction()

        Try
            'encontrar el codigo de la peli
            strSQL = "SELECT codigo FROM PELICULA WHERE titulo = ?"
            dbComm = New OleDbCommand(strSQL, conexion, transaccion)
            dbComm.Parameters.Add("param1", OleDbType.VarChar)
            dbComm.Parameters("param1").Value = PelisAlquiladas.SelectedValue
            Dim codigoPeliAl As Integer = dbComm.ExecuteScalar()
            MsgBox("Encontrado el codigo de la peli")

            'poner devuelta=S en alquiler
            strSQL = "UPDATE ALQUILER SET devuelta='S' WHERE codigo = ? AND usuarioLogin=?"
            dbComm = New OleDbCommand(strSQL, conexion, transaccion)
            dbComm.Parameters.Add("param1", OleDbType.Integer)
            dbComm.Parameters("param1").Value = codigoPeliAl
            dbComm.Parameters.Add("param2", OleDbType.VarChar)
            dbComm.Parameters("param2").Value = usuario
            dbComm.ExecuteNonQuery()
            MsgBox("Cambiado el estado")

            ' Ver si ha sobrepasado el tiempo de alquiler
            strSQL = "SELECT FechaFin FROM ALQUILER WHERE codigo = ?"
            dbComm = New OleDbCommand(strSQL, conexion, transaccion)
            dbComm.Parameters.Add("param1", OleDbType.Integer)
            dbComm.Parameters("param1").Value = codigoPeliAl
            Dim fechaDevuelta As Date = dbComm.ExecuteScalar()
            MsgBox("Encontrado el dia de devolucion")


            'cambiar estado de la peli, mirando si sigue alquilada por algun otro
            strSQL = "SELECT Count(*) FROM ALQUILER WHERE codigo = ? AND devuelta='N'"
            dbComm = New OleDbCommand(strSQL, conexion, transaccion)
            dbComm.Parameters.Add("param1", OleDbType.Integer)
            dbComm.Parameters("param1").Value = codigoPeliAl
            Dim numAlquileres As Integer = dbComm.ExecuteScalar()
            MsgBox("Vemos si alguien la tiene alquilada")

            If numAlquileres > 0 Then
                MsgBox("Alguien la tiene alquilada, no podemos cambiar el estado")
            Else
                MsgBox("Nadie la tiene alquilada, podemos cambiar el estado")
                strSQL = "UPDATE PELICULA SET estado='Disponible' WHERE codigo = ?"
                dbComm = New OleDbCommand(strSQL, conexion, transaccion)
                dbComm.Parameters.Add("param1", OleDbType.Integer)
                dbComm.Parameters("param1").Value = codigoPeliAl
                dbComm.ExecuteNonQuery()
                MsgBox("Actualizado el estado")
            End If

            'si ha pasado el tiempo, se le cobra precio*exceso de dias
            If Now > fechaDevuelta Then
                strSQL = "SELECT precio FROM PELICULA WHERE codigo = ?"
                dbComm = New OleDbCommand(strSQL, conexion, transaccion)
                dbComm.Parameters.Add("param1", OleDbType.Integer)
                dbComm.Parameters("param1").Value = codigoPeliAl
                Dim precioPeli As Integer = dbComm.ExecuteScalar()
                MsgBox("Obtenido el precio")



                Dim diferencia As TimeSpan = Now - fechaDevuelta

                ' Convierte la diferencia a d�as como un n�mero entero
                Dim exceso As Integer = CInt(diferencia.TotalDays)
                MsgBox("Obtenido el exceso")

                strSQL = "UPDATE USUARIOREG SET credito=credito-? WHERE usuarioLogin = ?"
                dbComm = New OleDbCommand(strSQL, conexion, transaccion)
                dbComm.Parameters.Add("param1", OleDbType.Integer)
                dbComm.Parameters("param1").Value = precioPeli * exceso

                dbComm.Parameters.Add("param2", OleDbType.VarChar)
                dbComm.Parameters("param2").Value = usuario
                dbComm.ExecuteNonQuery()
                MsgBox("Actualizado el credito")

            End If
            PelisAlquiladas.DataBind()

            transaccion.Commit()
        Catch ex As Exception
            MsgBox(ex.Message)
            transaccion.Rollback()
        Finally
            conexion.Close()
            conexion.Dispose()
        End Try

    End Sub
End Class