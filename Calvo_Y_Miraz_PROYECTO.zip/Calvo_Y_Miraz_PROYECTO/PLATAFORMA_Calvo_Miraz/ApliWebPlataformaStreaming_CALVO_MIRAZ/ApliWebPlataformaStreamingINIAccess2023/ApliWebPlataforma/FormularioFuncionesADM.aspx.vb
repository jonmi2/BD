Imports System.Data.OleDb 'Para las conexiones tipo OleDb -- ACCESS
Imports System.Globalization

Public Class FormularioFuncionesADM
    Inherits System.Web.UI.Page
    'Asigna a Usuario el LoginName actual pasado a min�sculas (para las comparaciones)
    Dim usuario As String = StrConv(System.Web.HttpContext.Current.User.Identity.Name, VbStrConv.Lowercase)
    'Indicamos la cadena de conexion (tipo OLEDB)
    Dim cadenaConexion As String = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\TEMP\Plataforma_CALVO_MIRAZ.mdb"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        'Asegurarse de que ha iniciado sesi�n como administrador
        If usuario = "" Then
            MsgBox("Debes Iniciar Sesi�n como administrador para poder operar aqui")
            Response.Redirect("default.aspx")
        Else
            If usuario <> "administrador" Then
                MsgBox("No eres el administrador. Solo puedes realizar las funciones del Usuario")
                Response.Redirect("default.aspx")
            End If
        End If
    End Sub

    Protected Sub VolverPrincipal_Click(sender As Object, e As EventArgs) Handles VolverPrincipal.Click
        Response.Redirect("default.aspx")
    End Sub

    Protected Sub usuarioCambiar_SelectedIndexChanged(sender As Object, e As EventArgs) Handles usuarioCambiar.SelectedIndexChanged
        ' Volvemos a cargar los datos en el DataList1 cuando cambie la selecci�n en usuarioCambiar
        DataList1.DataBind()
    End Sub

    Protected Sub DDLcod_SelectedIndexChanged(sender As Object, e As EventArgs) Handles DDLcod.SelectedIndexChanged
        ' Volvemos a cargar los datos en el DataList1 cuando cambie la selecci�n
        DataList2.DataBind()
    End Sub


    Protected Sub cambiarEstadoSocio_Click1(sender As Object, e As EventArgs) Handles cambiarEstadoSocio.Click
        'PASO 0. DECLARAR LAS VARIABLES NECESARIAS para las instrucciones de BD
        Dim conexion As OleDb.OleDbConnection
        Dim instruccionSQL As String
        Dim dbComm As OleDbCommand
        'PASO 1. CREAR UNA CONEXION CON LA BASE DE DATOS Y ABRIRLA
        conexion = New OleDb.OleDbConnection(cadenaConexion)
        conexion.Open()
        'PASO 2. PREPARAR LA INSTRUCCION SQL A EJECUTAR
        'Ponemos la instrucci�n SQL en un string, con un ? en cada sitio en el que vaya un par�metro
        instruccionSQL = "SELECT estado FROM USUARIOREG WHERE usuarioLogin=?"
        'La convertimos en un comando para poder a�adirle los valores de los par�metros
        dbComm = New OleDbCommand(instruccionSQL, conexion)
        'A�adimos los par�metros y especificamos sus valores
        'en el mismo orden en que aparecen en la instrucci�n SQL
        'Valor correspondiente a la primera ? de instruccionSQL
        dbComm.Parameters.Add("param1", OleDbType.VarChar)
        dbComm.Parameters("param1").Value = usuarioCambiar.Text
        'PASO 3. EJECUTAR LA INSTRUCCION SQL (hay 3 casos distintos, se elige el adecuado)
        Dim est As String
        est = dbComm.ExecuteScalar() 'Ejecuta cualquier instrucci�n que no sea SELECT
        If (est = "A") Then
            instruccionSQL = "UPDATE USUARIOREG SET estado='B' WHERE usuarioLogin=?"
        Else
            instruccionSQL = "UPDATE USUARIOREG SET estado='A' WHERE usuarioLogin=?"
        End If
        dbComm = New OleDbCommand(instruccionSQL, conexion)
        'A�adimos los par�metros y especificamos sus valores
        'en el mismo orden en que aparecen en la instrucci�n SQL
        'Valor correspondiente a la primera ? de instruccionSQL
        dbComm.Parameters.Add("param1", OleDbType.VarChar)
        dbComm.Parameters("param1").Value = usuarioCambiar.Text
        dbComm.ExecuteNonQuery()
        'Sacamos un mensaje por pantalla (opcional)
        MsgBox("Se ha cambiado el estado")

        ' Volvemos a enlazar los datos al DataList1 despu�s de cambiar el estado del usuario
        DataList1.DataBind()
        'PASO 4. CERRAR LA CONEXI�N CON LA BASE DE DATOS Y LIBERAR MEMORIA
        conexion.Close()
        conexion.Dispose()
    End Sub

    Protected Sub mostrarDatosSocio_Click(sender As Object, e As EventArgs) Handles mostrarDatosSocio.Click
        If DataList1.Visible Then
            ' Si el DataList1 est� visible, lo ocultamos
            DataList1.Visible = False
        Else
            ' Si el DataList1 est� oculto, lo mostramos
            DataList1.Visible = True
            ' Volvemos a enlazar los datos para asegurarnos de que est�n actualizados
            DataList1.DataBind()
        End If
    End Sub

    Protected Sub DarDeAltaPeli_Click(sender As Object, e As EventArgs) Handles DarDeAltaPeli.Click
        'PASO 0. DECLARAR LAS VARIABLES NECESARIAS para las instrucciones de BD
        Dim conexion As OleDb.OleDbConnection
        Dim instruccionSQL As String
        Dim dbComm As OleDbCommand
        'PASO 1. CREAR UNA CONEXION CON LA BASE DE DATOS Y ABRIRLA
        conexion = New OleDb.OleDbConnection(cadenaConexion)
        conexion.Open()
        'PASO 2. PREPARAR LA INSTRUCCION SQL A EJECUTAR
        'Ponemos la instrucci�n SQL en un string, con un ? en cada sitio en el que vaya un par�metro
        instruccionSQL = "INSERT INTO PELICULA (codigo,titulo,precio) VALUES (?,?,?)"
        'La convertimos en un comando para poder a�adirle los valores de los par�metros
        dbComm = New OleDbCommand(instruccionSQL, conexion)
        'A�adimos los par�metros y especificamos sus valores
        'en el mismo orden en que aparecen en la instrucci�n SQL
        'Valor correspondiente a la primera ? de instruccionSQL
        dbComm.Parameters.Add("param1", OleDbType.Double)
        dbComm.Parameters("param1").Value = codPeliculaAlta.Text
        'Valor correspondiente a la segunda ? de instruccionSQL
        dbComm.Parameters.Add("param2", OleDbType.VarChar)
        dbComm.Parameters("param2").Value = TituloPeli.Text
        'Valor correspondiente a la tercera ? de instruccionSQL
        dbComm.Parameters.Add("param3", OleDbType.VarChar)
        dbComm.Parameters("param3").Value = PrecioPeli.Text
        'PASO 3. EJECUTAR LA INSTRUCCION SQL (hay 3 casos distintos, se elige el adecuado)
        dbComm.ExecuteNonQuery() 'Ejecuta cualquier instrucci�n que no sea SELECT
        'Sacamos un mensaje por pantalla (opcional)
        MsgBox("Se ha dado de alta una peli")
        'PASO 4. CERRAR LA CONEXI�N CON LA BASE DE DATOS Y LIBERAR MEMORIA
        conexion.Close()
        conexion.Dispose()
    End Sub

    Protected Sub DarDeBajaPeli_Click(sender As Object, e As EventArgs) Handles DarDeBajaPeli.Click
        ' PASO 0. DECLARAR LAS VARIABLES NECESARIAS para las instrucciones de BD
        Dim conexion As OleDb.OleDbConnection
        Dim instruccionSQL As String
        Dim dbComm As OleDbCommand
        ' PASO 1. CREAR UNA CONEXION CON LA BASE DE DATOS Y ABRIRLA
        conexion = New OleDb.OleDbConnection(cadenaConexion)
        conexion.Open()
        ' PASO 2. PREPARAR LA INSTRUCCION SQL A EJECUTAR
        ' Ponemos la instrucci�n SQL en un string, con un ? en cada sitio en el que vaya un par�metro
        instruccionSQL = "SELECT estado, fechaFinDisponible FROM PELICULA WHERE codigo=?"
        ' La convertimos en un comando para poder a�adirle los valores de los par�metros
        dbComm = New OleDbCommand(instruccionSQL, conexion)
        ' A�adimos los par�metros y especificamos sus valores
        ' en el mismo orden en que aparecen en la instrucci�n SQL
        ' Valor correspondiente a la primera ? de instruccionSQL
        dbComm.Parameters.Add("param1", OleDbType.Integer)
        dbComm.Parameters("param1").Value = Integer.Parse(DDLcod.SelectedValue)
        ' PASO 3. EJECUTAR LA INSTRUCCION SQL (hay 3 casos distintos, se elige el adecuado)
        Dim est As String
        Using reader As OleDbDataReader = dbComm.ExecuteReader() ' Ejecuta SELECT
            If reader.Read() Then
                est = reader.GetString(0)
                If (est = "Alquilada" Or est = "Disponible") Then
                    instruccionSQL = "UPDATE PELICULA SET estado='Descatalogada', fechaFinDisponible=DateAdd('d', 2, Now()) WHERE codigo=?"
                    'Sacamos un mensaje por pantalla (opcional)
                    MsgBox("Se ha dado de baja")
                ElseIf (est = "Descatalogada") Then
                    If (Now > reader.GetDateTime(1)) Then
                        ' Eliminamos las etiquetas asociadas a la pel�cula
                        Dim deleteEtiquetasSQL As String = "DELETE FROM ETIQUETA WHERE codigo=?"
                        Dim dbCommEtiquetas As New OleDbCommand(deleteEtiquetasSQL, conexion)
                        dbCommEtiquetas.Parameters.Add("param1", OleDbType.Integer).Value = Integer.Parse(DDLcod.SelectedValue)
                        dbCommEtiquetas.ExecuteNonQuery()

                        ' Eliminamos las valoraciones asociadas a la pel�cula
                        Dim deleteValoracionesSQL As String = "DELETE FROM VALORACION WHERE codigo=?"
                        Dim dbCommValoraciones As New OleDbCommand(deleteValoracionesSQL, conexion)
                        dbCommValoraciones.Parameters.Add("param1", OleDbType.Integer).Value = Integer.Parse(DDLcod.SelectedValue)
                        dbCommValoraciones.ExecuteNonQuery()

                        instruccionSQL = "DELETE FROM PELICULA WHERE codigo=?"

                        MsgBox("Se ha BORRADO")
                    Else
                        MsgBox("No se borra por que NO ha pasado la fecha fin disponibilidad")
                    End If
                End If
            Else
                ' Si no se encontr� la pel�cula, puedes mostrar un mensaje o hacer otra acci�n
                MsgBox("La pel�cula no fue encontrada, esto no deber�a pasar.")
                Return
            End If
        End Using

        ' Ejecutamos la instrucci�n SQL correspondiente
        dbComm = New OleDbCommand(instruccionSQL, conexion)
        ' A�adimos los par�metros y especificamos sus valores
        ' en el mismo orden en que aparecen en la instrucci�n SQL
        ' Valor correspondiente a la primera ? de instruccionSQL
        dbComm.Parameters.Add("param1", OleDbType.Integer)
        dbComm.Parameters("param1").Value = Integer.Parse(DDLcod.SelectedValue)
        dbComm.ExecuteNonQuery()
        ' Volvemos a enlazar los datos al DataList2 despu�s de cambiar el estado del usuario
        DataList2.DataBind()
        ' PASO 4. CERRAR LA CONEXI�N CON LA BASE DE DATOS Y LIBERAR MEMORIA
        conexion.Close()
        conexion.Dispose()
    End Sub


    Protected Sub mostrarDatosPeli_Click(sender As Object, e As EventArgs) Handles mostrarDatosPeli.Click
        If DataList2.Visible Then
            ' Si el DataList2 est� visible, lo ocultamos
            DataList2.Visible = False
        Else
            ' Si el DataList2 est� oculto, lo mostramos
            DataList2.Visible = True
            ' Volvemos a enlazar los datos para asegurarnos de que est�n actualizados
            DataList2.DataBind()
        End If
    End Sub
End Class
