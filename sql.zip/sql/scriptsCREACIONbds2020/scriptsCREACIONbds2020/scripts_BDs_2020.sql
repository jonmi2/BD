﻿-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	4.1.7-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema elmasri
--

CREATE DATABASE IF NOT EXISTS EMPRESA;
USE EMPRESA;

--
-- Definition of table `departamento`
--

DROP TABLE IF EXISTS `departamento`;
CREATE TABLE `departamento` (
  `nombreD` varchar(20) NOT NULL default '',
  `numeroD` int(11) NOT NULL default '0',
  `NSS_jefe` varchar(9) NOT NULL default '',
  `fecha_inic_jefe` date default NULL,
  PRIMARY KEY  (`numeroD`),
  UNIQUE KEY `nombreD` (`nombreD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `departamento`
--

/*!40000 ALTER TABLE `departamento` DISABLE KEYS */;
INSERT INTO `departamento` (`nombreD`,`numeroD`,`NSS_jefe`,`fecha_inic_jefe`) VALUES 
 ('Investigacion',5,'333445555','1988-05-22'),
 ('Administracion',4,'987654321','1995-01-01'),
 ('Direccion',1,'888665555','1981-06-19');
/*!40000 ALTER TABLE `departamento` ENABLE KEYS */;


--
-- Definition of table `dependiente`
--

DROP TABLE IF EXISTS `dependiente`;
CREATE TABLE `dependiente` (
  `NSSE` varchar(9) NOT NULL default '',
  `nombre_dependiente` varchar(15) NOT NULL default '',
  `sexo` char(1) default NULL,
  `fecha_ncto` date default NULL,
  `parentesco` varchar(8) default NULL,
  PRIMARY KEY  (`NSSE`,`nombre_dependiente`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dependiente`
--

/*!40000 ALTER TABLE `dependiente` DISABLE KEYS */;
INSERT INTO `dependiente` (`NSSE`,`nombre_dependiente`,`sexo`,`fecha_ncto`,`parentesco`) VALUES 
 ('333445555','Alicia','M','1986-04-05','HIJA'),
 ('333445555','Theodore','H','1983-10-25','HIJO'),
 ('333445555','Joy','M','1958-05-03','ESPOSA'),
 ('987654321','Abner','H','1942-02-28','ESPOSO'),
 ('123456789','Michael','H','1988-01-04','HIJO'),
 ('123456789','Alicia','M','1988-12-31','HIJA'),
 ('123456789','Elizabeth','M','1967-05-05','ESPOSA');
/*!40000 ALTER TABLE `dependiente` ENABLE KEYS */;


--
-- Definition of table `empleado`
--

DROP TABLE IF EXISTS `empleado`;
CREATE TABLE `empleado` (
  `nombre` varchar(15) NOT NULL default '',
  `inic` char(1) default NULL,
  `apellido` varchar(15) NOT NULL default '',
  `NSS` varchar(9) NOT NULL default '',
  `fecha_ncto` date default NULL,
  `direccion` varchar(30) default NULL,
  `sexo` char(1) default NULL,
  `salario` decimal(10,2) default NULL,
  `NSS_superv` varchar(9) default NULL,
  `ND` int(11) NOT NULL default '0',
  PRIMARY KEY  (`NSS`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empleado`
--

/*!40000 ALTER TABLE `empleado` DISABLE KEYS */;
INSERT INTO `empleado` (`nombre`,`inic`,`apellido`,`NSS`,`fecha_ncto`,`direccion`,`sexo`,`salario`,`NSS_superv`,`ND`) VALUES 
 ('John','B','Smith','123456789','1965-01-09','Fresnos 731, Houston, TX','H','30000.00','333445555',5),
 ('Franklin','T','Wong','333445555','1955-12-08','Valle 638, Houston, TX','H','40000.00','888665555',5),
 ('Alicia','J','Zelaya','999887777','1968-07-19','Castillo 3321, Sucre, TX','M','25000.00','987654321',4),
 ('Jennifer','S','Wallace','987654321','1941-06-20','Bravo 291, Bellaire, TX','M','43000.00','888665555',4),
 ('Ramesh','K','Narayan','666884444','1962-09-15','Espiga 875, Heras, TX','H','38000.00','333445555',5),
 ('Joyce','A','English','453453453','1972-07-31','Rosas 5631, Houston, TX','M','25000.00','333445555',5),
 ('Ahmad','V','Jabbar','987987987','1969-03-29','Dalias 980, Houston, TX','H','25000.00','987654321',4),
 ('Jaime','E','Borg','888665555','1937-11-10','Sorgo 450, Houston, TX','H','55000.00',NULL,1);
/*!40000 ALTER TABLE `empleado` ENABLE KEYS */;


--
-- Definition of table `localizaciones_dept`
--

DROP TABLE IF EXISTS `localizaciones_dept`;
CREATE TABLE `localizaciones_dept` (
  `numeroD` int(11) NOT NULL default '0',
  `localizacionD` varchar(15) NOT NULL default '',
  PRIMARY KEY  (`numeroD`,`localizacionD`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `localizaciones_dept`
--

/*!40000 ALTER TABLE `localizaciones_dept` DISABLE KEYS */;
INSERT INTO `localizaciones_dept` (`numeroD`,`localizacionD`) VALUES 
 (1,'Houston'),
 (4,'Stafford'),
 (5,'Bellaire'),
 (5,'Houston'),
 (5,'Sugarland');
/*!40000 ALTER TABLE `localizaciones_dept` ENABLE KEYS */;


--
-- Definition of table `proyecto`
--

DROP TABLE IF EXISTS `proyecto`;
CREATE TABLE `proyecto` (
  `nombreP` varchar(20) NOT NULL default '',
  `numeroP` int(11) NOT NULL default '0',
  `localizacionP` varchar(15) default NULL,
  `numD` int(11) NOT NULL default '0',
  PRIMARY KEY  (`numeroP`),
  UNIQUE KEY `nombreP` (`nombreP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proyecto`
--

/*!40000 ALTER TABLE `proyecto` DISABLE KEYS */;
INSERT INTO `proyecto` (`nombreP`,`numeroP`,`localizacionP`,`numD`) VALUES 
 ('ProductoX',1,'Bellaire',5),
 ('ProductoY',2,'Sugarland',5),
 ('ProductoZ',3,'Houston',5),
 ('Automatizacion',10,'Stafford',4),
 ('Reorganizacion',20,'Houston',1),
 ('Nuevos beneficios',30,'Stafford',4);
/*!40000 ALTER TABLE `proyecto` ENABLE KEYS */;


--
-- Definition of table `trabaja_en`
--

DROP TABLE IF EXISTS `trabaja_en`;
CREATE TABLE `trabaja_en` (
  `NSSE` char(9) NOT NULL default '',
  `NP` int(11) NOT NULL default '0',
  `horas` decimal(3,1) default NULL,
  PRIMARY KEY  (`NSSE`,`NP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trabaja_en`
--

/*!40000 ALTER TABLE `trabaja_en` DISABLE KEYS */;
INSERT INTO `trabaja_en` (`NSSE`,`NP`,`horas`) VALUES 
 ('123456789',1,'32.5'),
 ('123456789',2,'7.5'),
 ('666884444',3,'40.0'),
 ('453453453',1,'20.0'),
 ('453453453',2,'20.0'),
 ('333445555',2,'10.0'),
 ('333445555',3,'10.0'),
 ('333445555',10,'10.0'),
 ('333445555',20,'10.0'),
 ('999887777',30,'30.0'),
 ('999887777',10,'10.0'),
 ('987987987',10,'35.0'),
 ('987987987',30,'5.0'),
 ('987654321',30,'20.0'),
 ('987654321',20,'15.0'),
 ('888665555',20,NULL);
/*!40000 ALTER TABLE `trabaja_en` ENABLE KEYS */;

--
-- Create schema buques_sin_innodb
--

CREATE DATABASE IF NOT EXISTS buques;
USE buques;

--
-- Definition of table `buque`
--

DROP TABLE IF EXISTS `buque`;
CREATE TABLE `buque` (
  `nombrebuque` varchar(20) default NULL,
  `duenio` varchar(20) default NULL,
  `tipo` int(11) default NULL,
  `nombrepuerto` varchar(20) default NULL,
  `nombrepais` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buque`
--

/*!40000 ALTER TABLE `buque` DISABLE KEYS */;
INSERT INTO `buque` (`nombrebuque`,`duenio`,`tipo`,`nombrepuerto`,`nombrepais`) VALUES 
 ('Bilbao','Onassis',10,'LaRochelle','France\r'),
 ('AndraMari','Kennedy',20,'Detroit','USA\r'),
 ('Fletan','Kirk',20,'Vancouver','Canada\r'),
 ('Osakaka','OsakaSan',30,'Osaka','Japon\r'),
 ('Fly','Smith',40,'Oslo','Noruega\r');
/*!40000 ALTER TABLE `buque` ENABLE KEYS */;


--
-- Definition of table `estadopais`
--

DROP TABLE IF EXISTS `estadopais`;
CREATE TABLE `estadopais` (
  `nombrepais` varchar(20) default NULL,
  `continente` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `estadopais`
--

/*!40000 ALTER TABLE `estadopais` DISABLE KEYS */;
INSERT INTO `estadopais` (`nombrepais`,`continente`) VALUES 
 ('France','Europa Occidental\r'),
 ('USA','America\r'),
 ('Mexico','America\r'),
 ('UK','Europa Occidental\r'),
 ('Rumania','Europa del Este\r'),
 ('Japon','Asia\r'),
 ('Noruega','Europa del Norte\r'),
 ('Canada','America\r'),
 ('Espania','Europa del Sur\r');
/*!40000 ALTER TABLE `estadopais` ENABLE KEYS */;


--
-- Definition of table `maroceanolago`
--

DROP TABLE IF EXISTS `maroceanolago`;
CREATE TABLE `maroceanolago` (
  `nombremar` varchar(20) default NULL,
  `profundidad` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `maroceanolago`
--

/*!40000 ALTER TABLE `maroceanolago` DISABLE KEYS */;
INSERT INTO `maroceanolago` (`nombremar`,`profundidad`) VALUES 
 ('Atlantico',6000),
 ('Cantabrico',3300),
 ('Egeo',1500),
 ('Indico',4700),
 ('Mediterraneo',2000),
 ('Negro',1300),
 ('Pacifico',5200),
 ('Rojo',1100),
 ('Eire',1000),
 ('Superior',1200),
 ('Aral',2000),
 ('Norte',2100);
/*!40000 ALTER TABLE `maroceanolago` ENABLE KEYS */;


--
-- Definition of table `movimientobuque`
--

DROP TABLE IF EXISTS `movimientobuque`;
CREATE TABLE `movimientobuque` (
  `nombrebuque` varchar(20) default NULL,
  `fechahora` datetime default NULL,
  `longitud` int(11) default NULL,
  `latitud` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `movimientobuque`
--

/*!40000 ALTER TABLE `movimientobuque` DISABLE KEYS */;
INSERT INTO `movimientobuque` (`nombrebuque`,`fechahora`,`longitud`,`latitud`) VALUES 
 ('Osakaka','2001-01-02 00:00:00',100,150),
 ('Osakaka','2001-01-02 01:30:00',125,110),
 ('AndraMari','2001-01-03 00:00:00',100,100);
/*!40000 ALTER TABLE `movimientobuque` ENABLE KEYS */;


--
-- Definition of table `puerto`
--

DROP TABLE IF EXISTS `puerto`;
CREATE TABLE `puerto` (
  `nombrepuerto` varchar(20) default NULL,
  `nombrepais` varchar(20) default NULL,
  `nombremar` varchar(20) default NULL,
  `descrip` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `puerto`
--

/*!40000 ALTER TABLE `puerto` DISABLE KEYS */;
INSERT INTO `puerto` (`nombrepuerto`,`nombrepais`,`nombremar`,`descrip`) VALUES 
 ('LaRochelle','France','Atlantico','Cap. 2000 barcos\r'),
 ('Osaka','Japon','Pacifico','Cap. 300 barcos\r'),
 ('Vancouver','Canada','Pacifico','Rocas en el fondo\r'),
 ('Detroit','USA','Eire','\r'),
 ('Oslo','Noruega','Norte','Hielos\r'),
 ('Santander','Espania','Cantabrico','NULL\r'),
 ('Vigo','Espania','Atlantico','Chapapote\r'),
 ('Cadiz','Espania','Atlantico','Fuertes vientos\r');
/*!40000 ALTER TABLE `puerto` ENABLE KEYS */;


--
-- Definition of table `tipobuque`
--

DROP TABLE IF EXISTS `tipobuque`;
CREATE TABLE `tipobuque` (
  `tipo` int(11) default NULL,
  `tonelaje` decimal(7,2) default NULL,
  `casco` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tipobuque`
--

/*!40000 ALTER TABLE `tipobuque` DISABLE KEYS */;
INSERT INTO `tipobuque` (`tipo`,`tonelaje`,`casco`) VALUES 
 (10,'3500.00','Fibra Vidrio\r'),
 (20,'50000.00','Acero\r'),
 (30,'500.00','Madera\r'),
 (40,'1.00','Plastico\r');
/*!40000 ALTER TABLE `tipobuque` ENABLE KEYS */;


--
-- Definition of table `visita`
--

DROP TABLE IF EXISTS `visita`;
CREATE TABLE `visita` (
  `nombrebuque` varchar(20) default NULL,
  `nombrepuerto` varchar(20) default NULL,
  `nombrepais` varchar(20) default NULL,
  `fechainicio` datetime default NULL,
  `fechafin` datetime default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `visita`
--

/*!40000 ALTER TABLE `visita` DISABLE KEYS */;
INSERT INTO `visita` (`nombrebuque`,`nombrepuerto`,`nombrepais`,`fechainicio`,`fechafin`) VALUES 
 ('AndraMari','Santander','Espania','2000-11-22 00:00:00','2000-11-22 00:00:00'),
 ('AndraMari','Vigo','Espania','2000-11-23 00:00:00','2000-11-24 00:00:00'),
 ('AndraMari','Cadiz','Espania','2000-11-25 00:00:00','2000-11-25 00:00:00'),
 ('Bilbao','Santander','Espania','2001-01-01 00:00:00','2001-01-02 00:00:00'),
 ('Bilbao','Vigo','Espania','2001-01-18 00:00:00','2001-01-18 00:00:00'),
 ('Bilbao','Cadiz','Espania','2001-01-05 00:00:00','2001-01-09 00:00:00'),
 ('AndraMari','Cadiz','Espania','2000-11-26 00:00:00','2000-11-30 00:00:00'),
 ('Fletan','Santander','Espania','2000-05-01 00:00:00','2000-05-07 00:00:00'),
 ('Fletan','Cadiz','Espania','2000-05-07 00:00:00','2000-05-18 00:00:00'),
 ('Osakaka','Santander','Espania','2000-03-26 00:00:00','2000-03-27 00:00:00'),
 ('Osakaka','Vigo','Espania','2000-03-28 00:00:00','2000-03-29 00:00:00'),
 ('Osakaka','Cadiz','Espania','2000-04-02 00:00:00','2000-04-07 00:00:00');
/*!40000 ALTER TABLE `visita` ENABLE KEYS */;

--
-- Create schema repres_ventas
--

CREATE DATABASE IF NOT EXISTS repres_ventas;
USE repres_ventas;

--
-- Definition of table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
CREATE TABLE `clientes` (
  `numclie` double default NULL,
  `nombre` varchar(255) default NULL,
  `repclie` double default NULL,
  `limitecredito` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clientes`
--

/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` (`numclie`,`nombre`,`repclie`,`limitecredito`) VALUES 
 (2101,'Luis Garcia Anton',106,650),
 (2102,'Alvaro Rodriguez',101,650),
 (2103,'Jaime Llorens',105,500),
 (2105,'Antonio Canales',101,650),
 (2106,'Juan Suarez',102,650),
 (2107,'Julian Lopez',110,350),
 (2108,'Julia Antequera',109,550),
 (2109,'Alberto Juanes',103,250),
 (2111,'Cristobal Garcia',103,500),
 (2112,'Maria Silva',108,500),
 (2113,'Silvia Maron',104,200),
 (2114,'Cristina Bulini',102,200),
 (2115,'Vicente Martinez',101,200),
 (2117,'Carlos Tena',106,350),
 (2118,'Junipero Alvarez',108,600),
 (2119,'Salomon Bueno',109,250),
 (2120,'Juan Malo',102,500),
 (2121,'Vicente Rios',103,450),
 (2122,'Jose Marchante',105,300),
 (2123,'Jose Libros',102,400),
 (2124,'Juan Bolto',107,400);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;


--
-- Definition of table `empleados`
--

DROP TABLE IF EXISTS `empleados`;
CREATE TABLE `empleados` (
  `numemp` double default NULL,
  `nombre` varchar(255) default NULL,
  `edad` double default NULL,
  `oficina` double default NULL,
  `titulo` varchar(255) default NULL,
  `contrato` date default NULL,
  `jefe` double default NULL,
  `cuota` double default NULL,
  `ventas` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `empleados`
--

/*!40000 ALTER TABLE `empleados` DISABLE KEYS */;
INSERT INTO `empleados` (`numemp`,`nombre`,`edad`,`oficina`,`titulo`,`contrato`,`jefe`,`cuota`,`ventas`) VALUES 
 (101,'Antonio Viguer',45,12,'representante','1986-10-20',104,3000,3050),
 (102,'Alvaro Jaumes',48,21,'representante','1986-12-10',108,3500,4740),
 (103,'Juan Rovira',29,12,'representante','1987-03-01',104,2750,2860),
 (104,'Jose Gonzalez',33,12,'dir ventas','1987-05-19',106,2000,1430),
 (105,'Vicente Pantalla',37,13,'representante','1988-02-12',104,3500,3680),
 (106,'Luis Antonio',52,11,'dir general','1988-06-14',NULL,2750,2990),
 (107,'Jorge Gutierrez',49,22,'representante','1988-11-14',108,3000,1860),
 (108,'Ana Bustamante',62,21,'dir ventas','1989-01-12',106,3500,3610),
 (109,'Maria Sunta',31,11,'representante','1999-10-12',106,3000,3920),
 (110,'Juan Victor',41,NULL,'representante','1990-01-13',104,NULL,760);
/*!40000 ALTER TABLE `empleados` ENABLE KEYS */;


--
-- Definition of table `oficinas`
--

DROP TABLE IF EXISTS `oficinas`;
CREATE TABLE `oficinas` (
  `oficina` double default NULL,
  `ciudad` varchar(255) default NULL,
  `region` varchar(255) default NULL,
  `dir` double default NULL,
  `objetivo` double default NULL,
  `ventas` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `oficinas`
--

/*!40000 ALTER TABLE `oficinas` DISABLE KEYS */;
INSERT INTO `oficinas` (`oficina`,`ciudad`,`region`,`dir`,`objetivo`,`ventas`) VALUES 
 (11,'Valencia','este',106,6760,6990),
 (12,'Alicante','este',104,8000,7350),
 (13,'Castellon','este',105,3500,3680),
 (21,'Badajoz','oeste',108,7250,8360),
 (22,'A Corunia','oeste',101,1000,1000),
 (23,'Madrid','centro',108,2500,1500),
 (26,'Pamplona','norte',NULL,NULL,NULL),
 (28,'Valencia','este',NULL,9000,0);
/*!40000 ALTER TABLE `oficinas` ENABLE KEYS */;


--
-- Definition of table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
CREATE TABLE `pedidos` (
  `codigo` double default NULL,
  `numpedido` double default NULL,
  `fechapedido` date default NULL,
  `clie` double default NULL,
  `rep` double default NULL,
  `fab` varchar(255) default NULL,
  `producto` varchar(255) default NULL,
  `cant` double default NULL,
  `importe` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pedidos`
--

/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` (`codigo`,`numpedido`,`fechapedido`,`clie`,`rep`,`fab`,`producto`,`cant`,`importe`) VALUES 
 (1,1100036,'2002-01-02',2107,110,'aci','4100z',9,225),
 (2,1100036,'2002-01-02',2117,105,'rei','2a44l',7,315),
 (3,112963,'2002-05-10',2103,105,'aci','41004',28,32.76),
 (4,112968,'1995-01-11',2102,101,'aci','41004',34,39.78),
 (5,112975,'2002-02-11',2111,103,'rei','2a44g',6,21),
 (6,112979,'1994-10-12',2114,108,'aci','4100z',6,150),
 (7,112963,'2002-05-10',2103,105,'aci','41004',6,7.02),
 (8,112987,'2002-01-01',2103,105,'aci','4100y',11,275),
 (9,112989,'2002-12-10',2101,106,'fea','114',6,14.58),
 (10,112992,'1995-04-15',2118,108,'aci','41002',10,7.6),
 (11,112993,'2002-03-10',2106,102,'rei','2a45c',24,18.96),
 (12,112997,'2002-04-04',2124,107,'bic','41003',1,6.52),
 (13,113003,'2002-02-05',2108,109,'imnn','779c',3,56.25),
 (14,113007,'2002-01-01',2112,108,'imnn','773c',3,29.25),
 (15,113012,'2002-05-05',2111,105,'aci','41003',35,37.45),
 (16,113013,'2002-08-06',2118,108,'bic','41003',1,6.52),
 (17,113024,'2002-07-04',2114,108,'qsa','xk47',20,71),
 (18,113027,'2002-02-05',2103,105,'aci','41002',54,41.04),
 (19,113034,'2002-11-05',2107,110,'rei','2a45c',8,6.32),
 (20,113042,'2002-01-01',2113,101,'rei','2a44r',5,225),
 (21,113045,'2002-07-02',2112,108,'rei','2a44r',10,450),
 (22,113048,'2002-02-02',2120,102,'imnn','779c',2,37.5),
 (23,113049,'2002-04-04',2118,108,'qsa','xk47',2,7.75),
 (24,113051,'2002-07-06',2118,106,'qsa','xk47',4,14.2),
 (25,113055,'1995-04-01',2108,101,'aci','4100x',6,1.5),
 (26,113067,'2002-11-01',2111,103,'aci','4100x',24,6),
 (27,113058,'1994-07-04',2108,109,'fea','112',10,14.8),
 (28,113062,'2002-07-04',2124,107,'bic','41003',10,24.3),
 (29,113065,'2002-06-03',2106,102,'qsa','xk47',6,21.3);
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;


--
-- Definition of table `productos`
--

DROP TABLE IF EXISTS `productos`;
CREATE TABLE `productos` (
  `idfab` varchar(255) default NULL,
  `idproducto` varchar(255) default NULL,
  `descripcion` varchar(255) default NULL,
  `precio` double default NULL,
  `existencias` double default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `productos`
--

/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` (`idfab`,`idproducto`,`descripcion`,`precio`,`existencias`) VALUES 
 ('aci','41001','arandela',0.58,277),
 ('aci','41002','bisagra',0.8,167),
 ('aci','41003','art t3',1.12,207),
 ('aci','41004','art t4',1.23,139),
 ('aci','4100x','junta',0.26,37),
 ('aci','4100y','extractor',28.88,25),
 ('aci','4100z','mont',26.25,28),
 ('bic','41003','manivela',6.52,3),
 ('bic','41089','rodamiento',2.25,78),
 ('bic','41672','plato',1.8,0),
 ('fea','112','cubo',1.48,115),
 ('fea','114','cubo',2.43,15),
 ('imnn','773c','reostato',9.75,28),
 ('imnn','775c','reostato 2',14.25,5),
 ('imnn','779c','reostato 3',18.75,0),
 ('imnn','887h','caja clavos',0.54,223),
 ('imnn','887p','perno',0.25,24),
 ('imnn','887x','manivela',4.75,32),
 ('qsa','xk47','red',3.55,38),
 ('qsa','xk48','red',1.34,203),
 ('qssa','xk48a','red',1.17,37),
 ('rei','2a44g','pas',3.5,14),
 ('rei','2a44l','bomba l',45,12),
 ('rei','2a44r','bomba r',45,12),
 ('rei','2a45c','junta',0.79,210);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;

--
-- Create schema universidad
--

CREATE DATABASE IF NOT EXISTS universidad;
USE universidad;

--
-- Definition of table `alumno`
--

DROP TABLE IF EXISTS `alumno`;
CREATE TABLE `alumno` (
  `Nombre` varchar(20) default NULL,
  `Codigo_alumno` int(11) NOT NULL default '0',
  `Anio` smallint(6) default NULL,
  `Especialidad` varchar(50) default NULL,
  PRIMARY KEY  (`Codigo_alumno`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `alumno`
--

/*!40000 ALTER TABLE `alumno` DISABLE KEYS */;
INSERT INTO `alumno` (`Nombre`,`Codigo_alumno`,`Anio`,`Especialidad`) VALUES 
 ('Smith',17,1,'CS'),
 ('Brown',8,2,'CS'),
 ('Juan',22,1,'CS'),
 ('Pepe',23,3,'IT');
/*!40000 ALTER TABLE `alumno` ENABLE KEYS */;


--
-- Definition of table `curso`
--

DROP TABLE IF EXISTS `curso`;
CREATE TABLE `curso` (
  `Nombre_curso` varchar(30) default NULL,
  `Codigo_curso` varchar(50) NOT NULL default '',
  `Creditos` int(11) default NULL,
  `Departamento` varchar(50) default NULL,
  PRIMARY KEY  (`Codigo_curso`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `curso`
--

/*!40000 ALTER TABLE `curso` DISABLE KEYS */;
INSERT INTO `curso` (`Nombre_curso`,`Codigo_curso`,`Creditos`,`Departamento`) VALUES 
 ('Introd. a la computacion','CS1310',4,'LSI'),
 ('Estructuras de datos','CS3320',4,'LSI'),
 ('Matematicas discretas','MATE2410',3,'MATE'),
 ('Bases de datos','CS3380',6,'LSI'),
('Administracion de BD','CS3390',6,'LSI'),
('Diseno de BD','CS3400',6,'LSI');
/*!40000 ALTER TABLE `curso` ENABLE KEYS */;


--
-- Definition of table `informe_calificaciones`
--

DROP TABLE IF EXISTS `informe_calificaciones`;
CREATE TABLE `informe_calificaciones` (
  `Codigo_alumno` int(11) NOT NULL default '0',
  `Identificador_seccion` int(11) NOT NULL default '0',
  `Calificacion` char(1) default NULL,
  PRIMARY KEY  (`Codigo_alumno`,`Identificador_seccion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `informe_calificaciones`
--

/*!40000 ALTER TABLE `informe_calificaciones` DISABLE KEYS */;
INSERT INTO `informe_calificaciones` (`Codigo_alumno`,`Identificador_seccion`,`Calificacion`) VALUES 
 (17,112,'B'),
 (17,119,'C'),
 (8,85,'A'),
 (8,92,'A'),
 (8,112,'B'),
 (8,135,'A'),
 (22,112,'A'),
 (22,135,'A'),
 (23,112,'D');
/*!40000 ALTER TABLE `informe_calificaciones` ENABLE KEYS */;


--
-- Definition of table `matricula`
--

DROP TABLE IF EXISTS `matricula`;
CREATE TABLE `matricula` (
  `Codigo_alumno` int(11) NOT NULL default '0',
  `Precio_matricula` double default NULL,
  `Fecha_Hora` datetime default NULL,
  `Observaciones` mediumtext
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `matricula`
--

/*!40000 ALTER TABLE `matricula` DISABLE KEYS */;
INSERT INTO `matricula` (`Codigo_alumno`,`Precio_matricula`,`Fecha_Hora`,`Observaciones`) VALUES 
 (8,1000,'2002-10-01 10:00:00','Falta fotocopia del carnet de identidad'),
 (17,800,'2002-09-15 12:15:00',NULL);
/*!40000 ALTER TABLE `matricula` ENABLE KEYS */;


--
-- Definition of table `requisito`
--

DROP TABLE IF EXISTS `requisito`;
CREATE TABLE `requisito` (
  `Codigo_curso` varchar(50) NOT NULL default '',
  `Codigo_requisito` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`Codigo_curso`,`Codigo_requisito`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requisito`
--

/*!40000 ALTER TABLE `requisito` DISABLE KEYS */;
INSERT INTO `requisito` (`Codigo_curso`,`Codigo_requisito`) VALUES 
 ('CS3320','CS1310'),
 ('CS3380','CS3320'),
 ('CS3380','MATE2410'),
 ('CS3390','CS3380'),
 ('CS3400','CS3380');
/*!40000 ALTER TABLE `requisito` ENABLE KEYS */;


--
-- Definition of table `seccion`
--

DROP TABLE IF EXISTS `seccion`;
CREATE TABLE `seccion` (
  `Identificador_seccion` int(11) default NULL,
  `Codigo_curso` varchar(50) default NULL,
  `Semestre` varchar(50) default NULL,
  `Anio` int(11) default NULL,
  `Profesor` varchar(20) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seccion`
--

/*!40000 ALTER TABLE `seccion` DISABLE KEYS */;
INSERT INTO `seccion` (`Identificador_seccion`,`Codigo_curso`,`Semestre`,`Anio`,`Profesor`) VALUES 
 (85,'MATE2410','Otonio',1999,'King'),
 (92,'CS1310','Otonio',1998,'Anderson'),
 (102,'CS3320','Primavera',1999,'Knuth'),
 (112,'MATE2410','Otonio',1999,'Chang'),
 (119,'CS1310','Otonio',1999,'Anderson'),
 (135,'CS3380','Otonio',1999,'Stone'),
 (999,'MATE2410','primavera',2003,'Martin');
/*!40000 ALTER TABLE `seccion` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
