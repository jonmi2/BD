-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-03-2024 a las 12:56:16
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `empresa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `departamento`
--

CREATE TABLE `departamento` (
  `nombreD` varchar(20) NOT NULL DEFAULT '',
  `numeroD` int(11) NOT NULL DEFAULT 0,
  `NSS_jefe` varchar(9) NOT NULL DEFAULT '',
  `fecha_inic_jefe` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `departamento`
--

INSERT INTO `departamento` (`nombreD`, `numeroD`, `NSS_jefe`, `fecha_inic_jefe`) VALUES
('Investigacion', 5, '333445555', '1988-05-22'),
('Administracion', 4, '987654321', '1995-01-01'),
('Direccion', 1, '888665555', '1981-06-19');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `dependiente`
--

CREATE TABLE `dependiente` (
  `NSSE` varchar(9) NOT NULL DEFAULT '',
  `nombre_dependiente` varchar(15) NOT NULL DEFAULT '',
  `sexo` char(1) DEFAULT NULL,
  `fecha_ncto` date DEFAULT NULL,
  `parentesco` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `dependiente`
--

INSERT INTO `dependiente` (`NSSE`, `nombre_dependiente`, `sexo`, `fecha_ncto`, `parentesco`) VALUES
('333445555', 'Alicia', 'M', '1986-04-05', 'HIJA'),
('333445555', 'Theodore', 'H', '1983-10-25', 'HIJO'),
('333445555', 'Joy', 'M', '1958-05-03', 'ESPOSA'),
('987654321', 'Abner', 'H', '1942-02-28', 'ESPOSO'),
('123456789', 'Michael', 'H', '1988-01-04', 'HIJO'),
('123456789', 'Alicia', 'M', '1988-12-31', 'HIJA'),
('123456789', 'Elizabeth', 'M', '1967-05-05', 'ESPOSA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `empleado`
--

CREATE TABLE `empleado` (
  `nombre` varchar(15) NOT NULL DEFAULT '',
  `inic` char(1) DEFAULT NULL,
  `apellido` varchar(15) NOT NULL DEFAULT '',
  `NSS` varchar(9) NOT NULL DEFAULT '',
  `fecha_ncto` date DEFAULT NULL,
  `direccion` varchar(30) DEFAULT NULL,
  `sexo` char(1) DEFAULT NULL,
  `salario` decimal(10,2) DEFAULT NULL,
  `NSS_superv` varchar(9) DEFAULT NULL,
  `ND` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `empleado`
--

INSERT INTO `empleado` (`nombre`, `inic`, `apellido`, `NSS`, `fecha_ncto`, `direccion`, `sexo`, `salario`, `NSS_superv`, `ND`) VALUES
('John', 'B', 'Smith', '123456789', '1965-01-09', 'Fresnos 731, Houston, TX', 'H', 30000.00, '333445555', 5),
('Franklin', 'T', 'Wong', '333445555', '1955-12-08', 'Valle 638, Houston, TX', 'H', 40000.00, '888665555', 5),
('Alicia', 'J', 'Zelaya', '999887777', '1968-07-19', 'Castillo 3321, Sucre, TX', 'M', 25000.00, '987654321', 4),
('Jennifer', 'S', 'Wallace', '987654321', '1941-06-20', 'Bravo 291, Bellaire, TX', 'M', 43000.00, '888665555', 4),
('Ramesh', 'K', 'Narayan', '666884444', '1962-09-15', 'Espiga 875, Heras, TX', 'H', 38000.00, '333445555', 5),
('Joyce', 'A', 'English', '453453453', '1972-07-31', 'Rosas 5631, Houston, TX', 'M', 25000.00, '333445555', 5),
('Ahmad', 'V', 'Jabbar', '987987987', '1969-03-29', 'Dalias 980, Houston, TX', 'H', 25000.00, '987654321', 4),
('Jaime', 'E', 'Borg', '888665555', '1937-11-10', 'Sorgo 450, Houston, TX', 'H', 55000.00, NULL, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `localizaciones_dept`
--

CREATE TABLE `localizaciones_dept` (
  `numeroD` int(11) NOT NULL DEFAULT 0,
  `localizacionD` varchar(15) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `localizaciones_dept`
--

INSERT INTO `localizaciones_dept` (`numeroD`, `localizacionD`) VALUES
(1, 'Houston'),
(4, 'Stafford'),
(5, 'Bellaire'),
(5, 'Houston'),
(5, 'Sugarland');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyecto`
--

CREATE TABLE `proyecto` (
  `nombreP` varchar(20) NOT NULL DEFAULT '',
  `numeroP` int(11) NOT NULL DEFAULT 0,
  `localizacionP` varchar(15) DEFAULT NULL,
  `numD` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `proyecto`
--

INSERT INTO `proyecto` (`nombreP`, `numeroP`, `localizacionP`, `numD`) VALUES
('ProductoX', 1, 'Bellaire', 5),
('ProductoY', 2, 'Sugarland', 5),
('ProductoZ', 3, 'Houston', 5),
('Automatizacion', 10, 'Stafford', 4),
('Reorganizacion', 20, 'Houston', 1),
('Nuevos beneficios', 30, 'Stafford', 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trabaja_en`
--

CREATE TABLE `trabaja_en` (
  `NSSE` char(9) NOT NULL DEFAULT '',
  `NP` int(11) NOT NULL DEFAULT 0,
  `horas` decimal(3,1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Volcado de datos para la tabla `trabaja_en`
--

INSERT INTO `trabaja_en` (`NSSE`, `NP`, `horas`) VALUES
('123456789', 1, 32.5),
('123456789', 2, 7.5),
('666884444', 3, 40.0),
('453453453', 1, 20.0),
('453453453', 2, 20.0),
('333445555', 2, 10.0),
('333445555', 3, 10.0),
('333445555', 10, 10.0),
('333445555', 20, 10.0),
('999887777', 30, 30.0),
('999887777', 10, 10.0),
('987987987', 10, 35.0),
('987987987', 30, 5.0),
('987654321', 30, 20.0),
('987654321', 20, 15.0),
('888665555', 20, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `departamento`
--
ALTER TABLE `departamento`
  ADD PRIMARY KEY (`numeroD`),
  ADD UNIQUE KEY `nombreD` (`nombreD`);

--
-- Indices de la tabla `dependiente`
--
ALTER TABLE `dependiente`
  ADD PRIMARY KEY (`NSSE`,`nombre_dependiente`);

--
-- Indices de la tabla `empleado`
--
ALTER TABLE `empleado`
  ADD PRIMARY KEY (`NSS`);

--
-- Indices de la tabla `localizaciones_dept`
--
ALTER TABLE `localizaciones_dept`
  ADD PRIMARY KEY (`numeroD`,`localizacionD`);

--
-- Indices de la tabla `proyecto`
--
ALTER TABLE `proyecto`
  ADD PRIMARY KEY (`numeroP`),
  ADD UNIQUE KEY `nombreP` (`nombreP`);

--
-- Indices de la tabla `trabaja_en`
--
ALTER TABLE `trabaja_en`
  ADD PRIMARY KEY (`NSSE`,`NP`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
