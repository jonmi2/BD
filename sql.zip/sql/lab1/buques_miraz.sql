-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-02-2024 a las 18:51:43
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `buques_miraz`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `buque`
--

CREATE TABLE `buque` (
  `nombrebuque` varchar(20) NOT NULL,
  `duenio` varchar(20) DEFAULT NULL,
  `tipo` int(11) DEFAULT NULL,
  `nombrepuerto` varchar(20) DEFAULT NULL,
  `nombrepais` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estadopais`
--

CREATE TABLE `estadopais` (
  `nombrepais` varchar(20) NOT NULL,
  `continente` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `maroceanolago`
--

CREATE TABLE `maroceanolago` (
  `nombremar` varchar(20) NOT NULL,
  `profundidad` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `movimientobuque`
--

CREATE TABLE `movimientobuque` (
  `nombrebuque` varchar(10) NOT NULL,
  `fechahora` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `longitud` int(11) DEFAULT NULL,
  `latitud` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `puerto`
--

CREATE TABLE `puerto` (
  `nombrepuerto` varchar(20) NOT NULL,
  `nombrepais` varchar(20) NOT NULL,
  `nombremar` varchar(20) DEFAULT NULL,
  `descrip` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipobuque`
--

CREATE TABLE `tipobuque` (
  `tipo` int(11) NOT NULL,
  `tonelaje` decimal(7,2) DEFAULT NULL,
  `casco` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `visita`
--

CREATE TABLE `visita` (
  `nombrebuque` varchar(20) NOT NULL,
  `nombrepuerto` varchar(20) NOT NULL,
  `nombrepais` varchar(20) NOT NULL,
  `fechainicio` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fechafin` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `buque`
--
ALTER TABLE `buque`
  ADD PRIMARY KEY (`nombrebuque`),
  ADD KEY `nombrepuerto` (`nombrepuerto`,`nombrepais`),
  ADD KEY `tipo` (`tipo`);

--
-- Indices de la tabla `estadopais`
--
ALTER TABLE `estadopais`
  ADD PRIMARY KEY (`nombrepais`);

--
-- Indices de la tabla `maroceanolago`
--
ALTER TABLE `maroceanolago`
  ADD PRIMARY KEY (`nombremar`);

--
-- Indices de la tabla `movimientobuque`
--
ALTER TABLE `movimientobuque`
  ADD PRIMARY KEY (`nombrebuque`,`fechahora`);

--
-- Indices de la tabla `puerto`
--
ALTER TABLE `puerto`
  ADD PRIMARY KEY (`nombrepuerto`,`nombrepais`),
  ADD KEY `nombrepais` (`nombrepais`),
  ADD KEY `nombremar` (`nombremar`);

--
-- Indices de la tabla `tipobuque`
--
ALTER TABLE `tipobuque`
  ADD PRIMARY KEY (`tipo`);

--
-- Indices de la tabla `visita`
--
ALTER TABLE `visita`
  ADD PRIMARY KEY (`nombrebuque`,`nombrepuerto`,`nombrepais`,`fechainicio`),
  ADD KEY `nombrepuerto` (`nombrepuerto`,`nombrepais`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `buque`
--
ALTER TABLE `buque`
  ADD CONSTRAINT `buque_ibfk_1` FOREIGN KEY (`nombrepuerto`,`nombrepais`) REFERENCES `puerto` (`nombrepuerto`, `nombrepais`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `buque_ibfk_2` FOREIGN KEY (`tipo`) REFERENCES `tipobuque` (`tipo`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `movimientobuque`
--
ALTER TABLE `movimientobuque`
  ADD CONSTRAINT `movimientobuque_ibfk_1` FOREIGN KEY (`nombrebuque`) REFERENCES `buque` (`nombrebuque`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `puerto`
--
ALTER TABLE `puerto`
  ADD CONSTRAINT `puerto_ibfk_1` FOREIGN KEY (`nombrepais`) REFERENCES `estadopais` (`nombrepais`) ON UPDATE CASCADE,
  ADD CONSTRAINT `puerto_ibfk_2` FOREIGN KEY (`nombremar`) REFERENCES `maroceanolago` (`nombremar`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `visita`
--
ALTER TABLE `visita`
  ADD CONSTRAINT `visita_ibfk_1` FOREIGN KEY (`nombrebuque`) REFERENCES `buque` (`nombrebuque`) ON UPDATE CASCADE,
  ADD CONSTRAINT `visita_ibfk_2` FOREIGN KEY (`nombrepuerto`,`nombrepais`) REFERENCES `puerto` (`nombrepuerto`, `nombrepais`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
